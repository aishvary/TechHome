package com.techHome.constants;

/**
 * Created by Harsh on 5/16/2016.
 */
public class AboutUsRecyclerInformation {

    public String ques;
    public String ans;
}
