package com.techHome.constants;

/**
 * Created by Harsh on 12-May-16.
 */
public class ContactRecyclerInformation {

    public int name;
    public int pos;
    public String imgPhoto;

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getImgPhoto() {
        return imgPhoto;
    }

    public void setImgPhoto(String imgPhoto) {
        this.imgPhoto = imgPhoto;
    }
}
