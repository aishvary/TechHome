package com.techHome.constants;

/**
 * Created by Harsh on 4/29/2016.
 */
public class DashboardRecyclerInformation {

    public String iconId;
    public int title;
    public int desc;

    public String getIconId() {
        return iconId;
    }

    public void setIconId(String iconId) {
        this.iconId = iconId;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }

    public int getDesc() {
        return desc;
    }

    public void setDesc(int desc) {
        this.desc = desc;
    }
}
