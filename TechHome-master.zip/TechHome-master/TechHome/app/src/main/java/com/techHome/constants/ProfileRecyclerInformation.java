package com.techHome.constants;

/**
 * Created by Harsh on 4/29/2016.
 */
public class ProfileRecyclerInformation {

    public String attribute;
    public String value;

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
