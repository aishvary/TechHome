package com.techHome.constants;

/**
 * Created by Harsh on 7/25/2016.
 */
public class RatesRecyclerInformation {

    public String city;
    public String charges;
    public String condition;
    public String information;
}
